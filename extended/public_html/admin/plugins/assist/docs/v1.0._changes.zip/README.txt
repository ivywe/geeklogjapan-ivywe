ブロック用関数
    phpblock_shownewstories
自動タグ
    [newstories:話題ID RSSファイル]
      新着記事（おしらせ）
      例:[newstories:news news.rss]

    [newstories2:話題ID RSSファイルほか例参照]
      新着記事（おしらせ）
      例:[newstories2:news rss_file:news.rss title_trim_length:50 intervalday:70 limitcnt:40 newmarkday:30 thtml:xxxx]
      例:話題news を全件表示  [newstories2:news intervalday:0]
      例:話題news を/テーマ/xxxx/ のテンプレートで表示  [newstories2:news thtml:xxxx]
    [conf:変数名]
      $_CONF[変数名] の値を返す
      例：[conf:site_url]
          [conf:site_name]
          [conf:site_mail]
          [conf:site_slogan]

    [assist:usercount]              登録ユーザ数
    [assist:usercount_location]     location登録ユーザ数
